HaseCraft 2 with Cookie Clicker added.
Open index.html. Cookie Clicker uses the external scripts/assets included in the supplied code.
